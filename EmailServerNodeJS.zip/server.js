var express = require('express');
var app = express();
var nodemailer = require('nodemailer');
var path = require('path');
var EmailTemplate = require('email-templates').EmailTemplate;

var templatesDir = path.resolve(__dirname, 'app/templates');
var cors = require('cors')
app.use(cors())
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(express.static('app'));


var smtpTransport = nodemailer.createTransport({
	host: 'smtp.office365.com',
	service: 'office365',
	port: 587,
	auth: {
		user: 'admin@caymanall.com',
		pass: '@mifamiliayyo12'
	},
	tls: {
		rejectUnauthorized: false
	}
});

app.get('/sendConformationemail', function (req, res) {
	var template = new EmailTemplate(path.join(templatesDir, 'contact-request'));
	var locals = {
		email: req.query.email,
		name: req.query.name,
		message: req.query.message
	};

	template.render(locals, function (err, results) {
		if (err) {
			return console.error(err);
		}
		smtpTransport.sendMail({
			from: 'Caymanall',
			sender: 'Caymanall',
			to: req.query.email,
			subject: 'Purchase Confirmation',
			html: results.html,
			text: results.text
		}, function (err, responseStatus) {
			if (err) {
				res.end('error' + JSON.stringify(err));
			} else {
				res.end('sent');
			}
		});
	});
});

app.post('/sendpurchaseemaioltoadmin', function (req, res) {
	var template = new EmailTemplate(path.join(templatesDir, 'purchasealert'));
	var locals = {
		link: req.body.link,
		description: req.body.description,
		title: req.body.title,
		Username: req.body.Username,
		Emailuser: req.body.Emailuser,
		Verified: req.body.Verified,
		Price: req.body.Price
	};

	template.render(locals, function (err, results) {
		if (err) {
			return console.error(err);
		}
		smtpTransport.sendMail({
			from: 'Caymanall',
			sender: 'Caymanall',
			to: req.body.email,
			subject: 'Purchase Alert',
			html: results.html,
			text: results.text
		}, function (err, responseStatus) {
			if (err) {
				res.end('error' + JSON.stringify(err));
			} else {
				res.end('sent');
			}
		});
	});
});

app.post('/sendPromotions', function (req, res) {
	console.log(req.body);

	var template = new EmailTemplate(path.join(templatesDir, 'promotions'));
	var locals = {
		link: req.body.link,
		description: req.body.description,
		title: req.body.title,
		image: req.body.image,
	};

	template.render(locals, function (err, results) {
		if (err) {
			return console.error(err);
		}

		var count = 0;
		for (let k in req.body.email) {
			smtpTransport.sendMail({
				from: req.body.title,
				sender: req.body.title,
				to: req.body.email[k],
				subject: 'CaymanAll',
				html: results.html
			}, function (err, responseStatus) {
				if (err) {
					res.end('error' + JSON.stringify(err));
				} else {
					console.log(req.body.email[k]);
					count++;
					if (count == req.body.email.length) {
						res.end('sent');
					}

				}
			});
		}

	});
});

var server = app.listen(process.env.PORT || 3000, function () {
	var host = 'localhost';
	var port = server.address().port;
	console.log('Example app listening at http://%s:%s', host, port);
});