import { NgModule } from '@angular/core';
import { NbMenuModule } from '@nebular/theme';

import { ThemeModule } from '../@theme/theme.module';
import { PagesComponent } from './pages.component';
import { DashboardModule } from './dashboard/dashboard.module';
import { ECommerceModule } from './e-commerce/e-commerce.module';
import { PagesRoutingModule } from './pages-routing.module';
import { DashboardModuleReportAds } from './reportedads/dashboard.module';
import { DashboardModuleBanners } from './banners/dashboard.module';
import { DashboardModulepromotions } from './promotions/dashboard.module';

@NgModule({
  imports: [
    PagesRoutingModule,
    ThemeModule,
    NbMenuModule,
    DashboardModule,
    ECommerceModule,
    DashboardModuleReportAds,
    DashboardModuleBanners,
    DashboardModulepromotions
  
  ],
  declarations: [
    PagesComponent,
  ],
})
export class PagesModule {
}
