import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';

import { PagesComponent } from './pages.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ECommerceComponent } from './e-commerce/e-commerce.component';
import { DashboardComponentViewReportedAds } from './reportedads/dashboard.component';
import { DashboardComponentbanners } from './banners/dashboard.component';
import { DashboardComponentpromotions } from './promotions/dashboard.component';

const routes: Routes = [{
  path: '',
  component: PagesComponent,
  children: [
    {
      path: 'dashboard',
      component: ECommerceComponent,
    },
    {

      path: 'iot-dashboard',
      component: DashboardComponent,
    },
    {
      path: 'banners',
      component: DashboardComponentbanners,
    },
    {
      path: 'promotions',
      component: DashboardComponentpromotions,
    },

    {
      path: 'reportedads',
      component: DashboardComponentViewReportedAds,
    },
    {
      path: '',
      redirectTo: 'dashboard',
      pathMatch: 'full',
    }
  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PagesRoutingModule {
}
