import { Component } from '@angular/core';

import { MENU_ITEMS } from './pages-menu';
import { NbThemeService, NbDialogService } from '@nebular/theme';
import { AngularFireDatabase } from '@angular/fire/database';
import { UserActivityData } from '../@core/data/user-activity';
import { AngularFireAuth } from '@angular/fire/auth';
import { Router } from '@angular/router';

@Component({
  selector: 'ngx-pages',
  styleUrls: ['pages.component.scss'],
  template: `
    <ngx-one-column-layout>
      <nb-menu [items]="menu"></nb-menu>
      <router-outlet></router-outlet>
    </ngx-one-column-layout>
  `,
})
export class PagesComponent {

  constructor(private themeService: NbThemeService,
    public mdatabase: AngularFireDatabase,
    public mauth: AngularFireAuth,
    public dialogService: NbDialogService,
    public router: Router,
    private userActivityService: UserActivityData) {


    if (this.mauth.auth.currentUser) {
      this.menu = MENU_ITEMS
    } else {
      router.navigateByUrl('login');
    }
    this.menu = MENU_ITEMS


  }
  menu: any;
}
