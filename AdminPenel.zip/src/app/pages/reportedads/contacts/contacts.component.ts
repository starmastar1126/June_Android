import { Component, OnDestroy, TemplateRef } from '@angular/core';
import { takeWhile, retry } from 'rxjs/operators';
import { forkJoin } from 'rxjs';

import { Contacts, RecentUsers, UserData } from '../../../@core/data/users';
import { NbThemeService, NbDialogService } from '@nebular/theme';
import { AngularFireDatabase } from '@angular/fire/database';
import { UserActivityData } from '../../../@core/data/user-activity';

@Component({
  selector: 'ngx-contacts',
  styleUrls: ['./contacts.component.scss'],
  templateUrl: './contacts.component.html',
})
export class ContactsComponent implements OnDestroy {

  private alive = true;

  type = 'Pending';
  types = ['Paid', 'Pending', 'Paypal'];
  currentTheme: string;


  payments: Reproted[] = [];
  Adsall: Ads[] = [];

  temp: any;

  constructor(private themeService: NbThemeService,
    public mdatabase: AngularFireDatabase,
    public dialogService: NbDialogService,
    private userActivityService: UserActivityData) {
    this.themeService.getJsTheme()
      .pipe(takeWhile(() => this.alive))
      .subscribe(theme => {
        this.currentTheme = theme.name;
      });

    this.getUserActivity(this.type);

    this.mdatabase.list('ReportsAds').valueChanges().subscribe((data) => {

      this.temp = data;
      this.payments = this.temp;
      console.log(this.payments);


    });
  }

  getUserActivity(period: string) {

  }

  checkshow(item: Reproted) {
    if (!item.user.reported) {
      return true;
    } else {
      return false;
    }
  }

  selectedpayments: Reproted;
  linktoshare = "https://caymanall.page.link/?link=https://caymanall.page.link?-LmkB7Q9aAYn7LA7-7pb"
  open2(dialog: TemplateRef<any>, item: Reproted) {
    this.selectedpayments = item;
    this.linktoshare = "https://caymanall.page.link/?link=https://caymanall.page.link?" + this.selectedpayments.ads.id+"&apn=com.juanmckenzie.CaymanAll";
    this.dialogService.open(
      dialog,
      { context: 'this is some additional data passed to dialog' });
  }
  blockuser(dialog: TemplateRef<any>) {

    var unsub = this.mdatabase.list('ads').valueChanges().subscribe((data) => {
      unsub.unsubscribe();
      this.temp = data;
      this.Adsall = this.temp;
      for (let k in this.Adsall) {
        if (this.Adsall[k].sellerPointer.firebaseID.toString() === this.selectedpayments.ads.sellerPointer.firebaseID.toString()) {
          this.mdatabase.object('ads/' + this.Adsall[k].id).remove();
        }
      }
      this.mdatabase.object('users/' + this.selectedpayments.ads.sellerPointer.firebaseID + "/reported").set(true);
      this.mdatabase.object('ReportsAds/' + this.selectedpayments.id + "/user/reported").set(true);
    })

  }
  openlinl(dialog: TemplateRef<any>) {
    window.open(this.linktoshare);
  }



  ngOnDestroy() {
    this.alive = false;
  }


}
