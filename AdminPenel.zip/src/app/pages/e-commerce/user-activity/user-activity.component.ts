import { Component, OnDestroy, TemplateRef } from '@angular/core';
import { NbThemeService, NbDialogService } from '@nebular/theme';
import { takeWhile } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

import { UserActivityData, UserActive } from '../../../@core/data/user-activity';
import { AngularFireDatabase } from '@angular/fire/database';

@Component({
  selector: 'ngx-user-activity',
  styleUrls: ['./user-activity.component.scss'],
  templateUrl: './user-activity.component.html',
})
export class ECommerceUserActivityComponent implements OnDestroy {

  private alive = true;

  userActivity: UserActive[] = [];
  type = 'Pending';
  types = ['Paid', 'Pending', 'Paypal'];
  currentTheme: string;


  payments: payments[] = [];
  temp: any;

  constructor(private themeService: NbThemeService,
    private httpClient: HttpClient,
    public mdatabase: AngularFireDatabase,
    public dialogService: NbDialogService,
    private userActivityService: UserActivityData) {
    this.themeService.getJsTheme()
      .pipe(takeWhile(() => this.alive))
      .subscribe(theme => {
        this.currentTheme = theme.name;
      });

    this.getUserActivity(this.type);

    this.mdatabase.list('Banners').valueChanges().subscribe((data) => {

      this.temp = data;
      this.payments = this.temp;
      console.log(this.payments);


    });
  }

  getUserActivity(period: string) {



  }
  checkshowpaymentbutton() {

    if (this.type === 'Pending') {
      return true;
    } else {
      return false;
    }
  }
  selectedpayments: payments;
  open2(dialog: TemplateRef<any>, item: payments) {
    this.selectedpayments = item;
    this.dialogService.open(
      dialog,
      { context: 'this is some additional data passed to dialog' });
  }

  checkshow(payments: payments) {

    if (this.type === 'Pending') {
      if (!payments.statuslive) {
        return true;
      } else {
        return false;
      }
    }

    if (this.type === 'Paid') {
      if (payments.statuslive) {
        return true;
      } else {
        return false;
      }
    }

    if (this.type === 'Paypal') {
      if (payments.status) {
        return true;
      } else {
        return false;
      }
    }
  }

  ngOnDestroy() {
    this.alive = false;
  }

  getprcie(item: string) {
    if (item === '3') {
      return '$15';
    }

    if (item === '7') {
      return '$30';
    }

    if (item === '14') {
      return '$50';
    }

    if (item === '21') {
      return '$69';
    }

    if (item === '30') {
      return '$79';
    }

    if (item === '45') {
      return '$89';
    }

    return '$0';

  }

  cnoformclose(ref) {
    ref.close();
    this.httpClient.get('https://caymanall.appspot.com/sendConformationemail?name=' + this.selectedpayments.sellerPointer.fullName + '&email=' + this.selectedpayments.sellerPointer.email + '&message=Your Purchase has been completed successfully \n Banner(' + this.selectedpayments.title + ') is live now.&days=' + this.selectedpayments.days + '', { responseType: 'text' as 'json' }).subscribe((data) => {
      console.log(data);
      this.mdatabase.object('Banners/' + this.selectedpayments.id + "/statuslive").set(true).then((data) => {

      });

    });

  }
}
