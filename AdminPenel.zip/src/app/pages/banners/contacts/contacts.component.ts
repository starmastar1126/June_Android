import { Component, OnDestroy, TemplateRef, ChangeDetectorRef } from '@angular/core';
import { takeWhile, retry } from 'rxjs/operators';
import { forkJoin } from 'rxjs';
import { NbThemeService, NbDialogService } from '@nebular/theme';
import { AngularFireDatabase } from '@angular/fire/database';
import { UserActivityData, UserActive } from '../../../@core/data/user-activity';

@Component({
  selector: 'ngx-contacts',
  styleUrls: ['./contacts.component.scss'],
  templateUrl: './contacts.component.html',
})
export class ContactsComponent implements OnDestroy {

  private alive = true;

  userActivity: UserActive[] = [];
  type = 'Active';
  types = ['Active', 'Expired'];
  currentTheme: string;


  payments: payments[] = [];
  temp: any;

  constructor(private themeService: NbThemeService,
    public mdatabase: AngularFireDatabase,
    public dialogService: NbDialogService,
    private userActivityService: UserActivityData) {
    this.themeService.getJsTheme()
      .pipe(takeWhile(() => this.alive))
      .subscribe(theme => {
        this.currentTheme = theme.name;
      });

    this.getUserActivity(this.type);

    this.mdatabase.list('Banners').valueChanges().subscribe((data) => {

      this.temp = data;
      this.payments = this.temp;
      console.log(this.payments);


    });
  }

  getUserActivity(period: string) {



  }
  selectedpayments: payments;
  open2(dialog: TemplateRef<any>, item: payments) {
    this.selectedpayments = item;
    this.dialogService.open(
      dialog,
      { context: 'this is some additional data passed to dialog' });
  }

  checkshow(payments: payments) {

    if (this.type === 'Active') {
      var date1 = new Date();
      date1.setTime(Number(payments.createdAt))
      var date2 = new Date();
      var diff = Math.abs(date1.getTime() - date2.getTime());
      var diffDays = Math.ceil(diff / (1000 * 3600 * 24));
      if (diffDays < Number(payments.days)) {
        return true;
      } else {
        return false;
      }


    } else {
      var date1 = new Date();
      date1.setTime(Number(payments.createdAt))
      var date2 = new Date();
      var diff = Math.abs(date1.getTime() - date2.getTime());
      var diffDays = Math.ceil(diff / (1000 * 3600 * 24));


      if (diffDays < Number(payments.days)) {
        return false;
      } else {
        return true;
      }


    }

  }

  ngOnDestroy() {
    this.alive = false;
  }

  getprcie(item: string) {
    if (item === '3') {
      return '$15';
    }

    if (item === '7') {
      return '$30';
    }

    if (item === '14') {
      return '$50';
    }

    if (item === '21') {
      return '$69';
    }

    if (item === '30') {
      return '$79';
    }

    if (item === '45') {
      return '$89';
    }

    return '$0';

  }

  cnoformclose(ref) {
    this.mdatabase.object('Banners/' + this.selectedpayments.id).remove().then((data) => {
      ref.close();
    });
  }
}
