import { Injectable } from '@angular/core';
import { User } from 'firebase';
import { HttpClient } from '@angular/common/http/';
import { HttpHeaders } from '@angular/common/http';
import { AngularFireDatabase } from '@angular/fire/database';
import { AngularFireAuth } from '@angular/fire/auth';

@Injectable({
    providedIn: 'root'
})
export class AuthService {


    public selecteduserid = '';
    public selectedpropertyid = '';
    Users = [];
    constructor(
        public afAuth: AngularFireAuth, private httpweb: HttpClient, public database: AngularFireDatabase,
    ) { }



    doRegister(Email, Password) {
        return new Promise<any>((resolve, reject) => {
            this.afAuth.auth.createUserWithEmailAndPassword(Email, Password)
                .then(res => {
                    resolve(res);
                }, err => reject(err))
        })
    }

    doLogin(Email, Password) {
        return new Promise<any>((resolve, reject) => {
            this.database.list("USERS/").valueChanges().subscribe((data) => {

                this.Users = [];
                this.Users = data;
                for (let k in this.Users) {
                    console.log(this.Users[k].password);
                    console.log(this.Users[k].email);
                    console.log(Password);
                    console.log(Email);
                    if (this.Users[k].password === Password && this.Users[k].email === Email) {
                        if (this.Users[k].status === 'admin') {
                            console.log('in');
                            console.log(this.Users[k]);
                            console.log(this.Users[k].firebaseid);

                            localStorage.setItem("UID", this.Users[k].firebaseid);
                            localStorage.setItem("UserObj", this.Users[k]);
                            localStorage.setItem("User", this.Users[k].status);
                            localStorage.setItem("Name", this.Users[k].name);
                            localStorage.setItem("UserEmail", Email);
                            localStorage.setItem("Profile", this.Users[k].profile);
                            //   var myVar = moment(new Date()).format('YYYY/MM/DD hh:mm');
                            //   this.database.object('USERS/' + this.Users[k].firebaseid + "/lastlogin").set(myVar);
                            //   this.service.sendMessage(this.Users[k].roules);
                            resolve();
                        } else {
                            reject("No User Found");
                        }



                    }
                }
                reject("No User Found");


            });
        });


    }

    doLogout() {
        return new Promise((resolve, reject) => {
            if (this.afAuth.auth.currentUser) {
                this.afAuth.auth.signOut()
                resolve();
            }
            else {
                reject();
            }
        });
    }
    getCurrentUser() {
        return new Promise<any>((resolve, reject) => {
            var user = this.afAuth.auth.onAuthStateChanged(function (user: User) {
                if (user) {
                    resolve(user);
                } else {
                    reject('No user logged in');
                }
            })
        })
    }
    getUserInfo() {
        return new Promise<any>((resolve, reject) => {
            var user = this.afAuth.auth.onAuthStateChanged(function (user: User) {
                if (user) {
                    resolve(user);
                } else {
                    reject('No user logged in');
                }
            })
        })
    }
    resetPassword(email: string) {
        return this.afAuth.auth.sendPasswordResetEmail(email)
            .then(() => console.log('sent Password Reset Email!'))
            .catch((error) => console.log(error))
    }


    // showSuccess(Mesage) {
    //     this.toastr.successToastr(Mesage, 'Success!');
    // }

    // showError(Mesage) {
    //     this.toastr.errorToastr(Mesage, 'Oops!');
    // }
    RootObject: RootObject;


    sendNotification(Message, Title) {
        let body = {
            "notification": {
                "title": Title.toString(),
                "body": Message.toString(),
                "sound": "default",
                "click_action": "FCM_PLUGIN_ACTIVITY",
                "icon": "fcm_push_icon"
            },
            "data": {
                "title": Title.toString(),
                "body": Message.toString()
            },
            "to": '/topics/CaymanAll',
            "priority": "high",
            "restricted_package_name": ""
        }
        let options = new HttpHeaders().set('Content-Type', 'application/json');
        this.httpweb.post("https://fcm.googleapis.com/fcm/send", body, {
            headers: options.set('Authorization', 'key=AAAA-cK_PpE:APA91bHdEBTxLv8k9f-Ylr0QKbHaa5CMe3DTyjnEc1ZSWvNw6od3JuHV-nwcrCmJ_aNPTL1Y9zX6BJGjcTyZInJUlzjB_XSjo5kbmE3HMf8wZe8xvq2Ix9JMrQm4zTdNuH1yfQ_RdBNB'),
        })
            .subscribe(data => {
                console.log(JSON.stringify(data));
            });
    }
    sendNotificationcay(Message, Title) {
        let body = {
            "notification": {
                "title": Title.toString(),
                "body": Message.toString(),
                "sound": "default",
                "click_action": "FCM_PLUGIN_ACTIVITY",
                "icon": "fcm_push_icon"
            },
            "data": {
                "title": Title.toString(),
                "body": Message.toString()
            },
            "to": '/topics/CaymanAllIslandsTest',
            "priority": "high",
            "restricted_package_name": ""
        }
        let options = new HttpHeaders().set('Content-Type', 'application/json');
        this.httpweb.post("https://fcm.googleapis.com/fcm/send", body, {
            headers: options.set('Authorization', 'key=AAAA-cK_PpE:APA91bHdEBTxLv8k9f-Ylr0QKbHaa5CMe3DTyjnEc1ZSWvNw6od3JuHV-nwcrCmJ_aNPTL1Y9zX6BJGjcTyZInJUlzjB_XSjo5kbmE3HMf8wZe8xvq2Ix9JMrQm4zTdNuH1yfQ_RdBNB'),
        })
            .subscribe(data => {
                console.log(JSON.stringify(data));
            });
    }
    sendNotificationfcm(Message, Title, FCM) {
        let body = {
            "notification": {
                "title": Title.toString(),
                "body": Message.toString(),
                "sound": "default",
                "click_action": "FCM_PLUGIN_ACTIVITY",
                "icon": "fcm_push_icon"
            },
            "data": {
                "param1": "value1",
                "param2": "value2"
            },
            "to": FCM,
            "priority": "high",
            "restricted_package_name": ""
        }
        let options = new HttpHeaders().set('Content-Type', 'application/json');
        this.httpweb.post("https://fcm.googleapis.com/fcm/send", body, {
            headers: options.set('Authorization', 'key=AAAA-cK_PpE:APA91bHdEBTxLv8k9f-Ylr0QKbHaa5CMe3DTyjnEc1ZSWvNw6od3JuHV-nwcrCmJ_aNPTL1Y9zX6BJGjcTyZInJUlzjB_XSjo5kbmE3HMf8wZe8xvq2Ix9JMrQm4zTdNuH1yfQ_RdBNB'),
        })
            .subscribe(data => {
                console.log(JSON.stringify(data));
            });
    }

}


interface RootObject {
    to: string;
    notification: Notification;
}

interface Notification {
    body: string;
    title: string;
}