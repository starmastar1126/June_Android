import { Component, OnDestroy, TemplateRef, ChangeDetectorRef } from '@angular/core';
import { takeWhile, retry } from 'rxjs/operators';
import { forkJoin } from 'rxjs';
import { NbThemeService, NbDialogService } from '@nebular/theme';
import { AngularFireDatabase } from '@angular/fire/database';
import { UserActivityData, UserActive } from '../../../@core/data/user-activity';
import { AuthService } from '../services/auth.service';
import { AngularFireUploadTask, AngularFireStorage } from '@angular/fire/storage';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'ngx-contacts',
  styleUrls: ['./contacts.component.scss'],
  templateUrl: './contacts.component.html',
})
export class ContactsComponent implements OnDestroy {

  private alive = true;



  type = 'all users';
  types = ['all users', 'caymanall users'];


  area: String[] = [];
  emaillist = [];
  finalemaillist = [];
  temp: any;
  promotions: promotions = {} as promotions;

  promotionsall: promotions[];
  title = '';
  message = '';
  selectedptomotions = 'all';
  typeforpromotions = 'active';
  selectedptomotionssendemail = '';

  constructor(private themeService: NbThemeService,
    public mdatabase: AngularFireDatabase,
    public dialogService: NbDialogService,
    public authservices: AuthService,
    public storage: AngularFireStorage,
    public httpClient: HttpClient) {


    this.mdatabase.list('promotionsall').valueChanges().subscribe((data) => {
      this.temp = data;
      this.promotionsall = this.temp;
      console.log(this.promotionsall);


    });
    this.mdatabase.list('areas').valueChanges().subscribe((data) => {
      this.temp = data;
      this.area = this.temp;
      this.area.push('all');
      this.area = this.remove_duplicates_safe(this.area);
      this.area.reverse();
      console.log(this.area);

    });
  }

  remove_duplicates_safe(arr) {
    var seen = {};
    var ret_arr: String[] = [];
    for (var i = 0; i < arr.length; i++) {
      if (!(arr[i] in seen)) {
        ret_arr.push(arr[i].toString());
        seen[arr[i]] = true;
      }
    }
    return ret_arr;

  }

  sendpromotions() {

  }

  DateDiff(b: Date, e: Date) {
    let days = e.getDate() - b.getDate();
    return days;
  }

  selectedpayments: payments;
  open2(dialog: TemplateRef<any>, item: payments) {
    this.selectedpayments = item;
    this.dialogService.open(
      dialog,
      { context: 'this is some additional data passed to dialog' });
  }


  cnoformclose(ref) {
    this.mdatabase.object('promotionsall/' + this.selectedpayments.id).remove().then((data) => {
      ref.close();
    });
  }

  ngOnDestroy() {
    this.alive = false;
  }

  send() {
    if (this.type === 'caymanall users') {
      this.authservices.sendNotificationcay(this.message, this.title);
    } else {
      this.authservices.sendNotification(this.message, this.title);

    }
  }
  save() {


    if (!this.promotions.image) {
      return
    }
    if (!this.promotions.website) {
      return
    }
    if (!this.promotions.message) {
      return
    }
    this.promotions.id = this.mdatabase.list('promotionsall').push(this.promotions).key;
    this.mdatabase.object('promotionsall/' + this.promotions.id).set(this.promotions);

    this.mdatabase.list('emaillistwitharea/' + this.selectedptomotions).valueChanges().subscribe((data) => {
      this.temp = data;
      this.emaillist = this.temp;
      this.finalemaillist = [];
      for (let k in this.emaillist) {
        this.finalemaillist.push(this.emaillist[k])
      }
      var postdata = {} as postdata;
      postdata.email = this.finalemaillist;
      postdata.link = this.promotions.website;
      postdata.description = this.promotions.message;
      postdata.title = 'CaymalAll';
      postdata.image = this.promotions.image;

      console.log(JSON.stringify(postdata))
      const headers = new HttpHeaders({
        'Content-Type': 'application/json'
      });
      this.httpClient.post('http://localhost:3000/sendPromotions',
        JSON.stringify(postdata), { headers: headers })
        .subscribe(
          (val) => {
            console.log('POST call successful value returned in body',
              val);
          },
          response => {
            console.log('POST call in error', response);
          },
          () => {
            console.log('The POST observable is now completed.');
          });
      console.log(this.finalemaillist);
    });

  }
  checkshow(promotions: promotions) {
    var date1 = new Date();
    var date2 = new Date(new Date().setTime(Number(promotions.createdAt)));
    var diffMS = this.DateDiff(date1, date2);;
    if (diffMS > 30)
      return false;
    else return true;

  }

  private uploadTask: AngularFireUploadTask;
  private basePath: string = '/Images';
  image: any;
  onFileChanged(event) {


    const ref = this.storage.ref(`${this.basePath}/${new Date().getTime()}`);
    // let storageRef = firebase.storage().ref();
    console.log(event.target.files[0].name.toString().split('.')[event.target.files[0].name.toString().split('.').length - 1])
    if (event.target.files[0].name.toString().split('.')[event.target.files[0].name.toString().split('.').length - 1] === 'gif') {
      this.promotions.type = 'gif';
    } else {
      this.promotions.type = 'img';
    }
    console.log(this.promotions.type);
    this.uploadTask = ref.child(`${this.basePath}/${new Date().getTime()}` + '.' + event.target.files[0].name.toString().split('.')[event.target.files[0].name.toString().split('.').length - 1]).put(event.target.files[0]);
    console.log("0");
    this.uploadTask.then((snap) => {
      console.log("1");
      snap.ref.getDownloadURL().then(i => {
        console.log("2");
        console.log(i);
        this.image = i;
        this.promotions.image = this.image;
      });
    });

  }
}

interface promotions {
  id: string;
  message: string;
  website: string;
  type: string;
  createdAt: string;
  image: string;
}

interface postdata {
  link: string;
  description: string;
  title: string;
  image: string;
  email: string[];
}