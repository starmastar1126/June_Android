interface payments {
    category: string;
    createdAt: string;
    days: string;
    id: string;
    image1: string;
    location: Location;
    sellerPointer: SellerPointer8;
    status: boolean;
    statuslive: boolean;
    subcategory: string;
    title: string;
    url: string;
}
interface SellerPointer8 {
    aboutMe: string;
    age: string;
    avatar: string;
    email: string;
    emailVerified: boolean;
    expectinggander: string;
    fcm: string;
    firebaseID: string;
    fullName: string;
    gander: string;
    id: string;
    image2: string;
    joindate: string;
    latlong: Location;
    paid: boolean;
    reported: boolean;
    username: string;
    visibility: boolean;
}