interface Reproted {
    ads: Ads;
    id: string;
    message: string;
    user: SellerPointer;
  }
  
  interface Ads {
    adstatus: string;
    allDone: boolean;
    category: string;
    comments: number;
    condition: string;
    createdAt: string;
    currency: string;
    description: string;
    featured: boolean;
    id: string;
    image1: string;
    keywords: string[];
    likes: number;
    location: Location;
    paymentdone: boolean;
    price: number;
    reported: boolean;
    sellerPointer: SellerPointer;
    subcategory: string;
    title: string;
    type: boolean;
  }
  
  interface SellerPointer {
    age: string;
    avatar: string;
    email: string;
    emailVerified: boolean;
    expectinggander: string;
    fcm: string;
    firebaseID: string;
    fullName: string;
    gander: string;
    joindate: string;
    latlong: Location;
    paid: boolean;
    reported: boolean;
    username: string;
    visibility: boolean;
  }
  
  interface Location {
    latitude: number;
    longitude: number;
  }