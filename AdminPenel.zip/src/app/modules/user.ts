interface RootObject {
    FCM: string;
    age: string;
    avatar: string;
    bandage: boolean;
    email: string;
    emailVerified: boolean;
    expectinggander: string;
    firebaseID: string;
    fullName: string;
    gander: string;
    joindate: string;
    latlong: Latlong;
    likes: string[];
    paid: boolean;
    reported: boolean;
    username: string;
    visibility: boolean;
}


interface Latlong {
    latitude: number;
    longitude: number;
}  